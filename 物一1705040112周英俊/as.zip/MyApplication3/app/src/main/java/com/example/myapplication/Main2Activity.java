package com.example.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Main2Activity extends AppCompatActivity {

    private EditText et4;
    private EditText et5;
    private EditText et6;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Button button1=(Button) findViewById(R.id.btn5);
        Button button2=(Button) findViewById(R.id.btn6);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(Main2Activity.this,Main3Activity.class);
                startActivity(intent);
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(Main2Activity.this,MainActivity.class);
                startActivity(intent);
            }
        });
        Button button3=findViewById(R.id.btn2);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et4 = findViewById(R.id.et_4);
                et5 = findViewById(R.id.et_5);
                et6 = findViewById(R.id.et_6);
                String year = et4.getText().toString();
                String money = et5.getText().toString();
                Double a= Double.parseDouble(year);
                Double mm= Double.parseDouble(money);
                Double e=Math.E;
                Double c=0.28*(a-1960);
                Double b=4080*Math.pow(e ,c);
                Double res=b*mm/300;
                java.text.DecimalFormat   df1   =new   java.text.DecimalFormat("#.00");
                String res1= df1.format(res);
                et6.setText(res1);
            }
        });
    }
}
