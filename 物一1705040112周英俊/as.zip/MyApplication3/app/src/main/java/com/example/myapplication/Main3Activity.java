package com.example.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Main3Activity extends AppCompatActivity {
    private EditText et7;
    private EditText et8;
    private EditText et9;
    private EditText et10;
    private EditText et11;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        Button button1=(Button) findViewById(R.id.btn7);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(Main3Activity.this,Main2Activity.class);
                startActivity(intent);
            }
        });
        Button button2=findViewById(R.id.btn3);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et7 = findViewById(R.id.et_7);
                et8 = findViewById(R.id.et_8);
                et9 = findViewById(R.id.et_9);
                et10 = findViewById(R.id.et_10);
                et11 = findViewById(R.id.et_11);
                String year = et7.getText().toString();
                String money = et8.getText().toString();
                Double a= Double.parseDouble(year);
                Double mm= Double.parseDouble(money);
                Double e=Math.E;
                Double c=0.28*(a-1960);
                Double b=4080*Math.pow(e ,c);
                java.text.DecimalFormat   df1   =new   java.text.DecimalFormat("#.00");
                String res1= df1.format(b);
                et10.setText(res1);
                Double P1=0.3*Math.pow(0.72,a-1974);
                java.text.DecimalFormat   df2   =new   java.text.DecimalFormat("#.00");
                String res2= df2.format(b);
                et11.setText(res2);
                Double res=b*mm/900;
                java.text.DecimalFormat   df3  =new   java.text.DecimalFormat("#.00");
                String res3= df3.format(res);
                et9.setText(res3);
            }
        });
    }
}
