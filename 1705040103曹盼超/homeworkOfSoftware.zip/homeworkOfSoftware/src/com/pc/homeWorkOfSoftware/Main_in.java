package com.pc.homeWorkOfSoftware;

import javax.swing.JTextField;

public class Main_in {
	public static void main(String[] args) {
        // TODO Auto-generated method stub
//		try {
//			//Object org;
//			org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper.launchBeautyEyeLNF();// ����BeautyEye����
//			//org.jb2011.lnf.beautyeye.ch10_internalframe.BEInternalFrameUI.createUI(c);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
		test test= new  test();
		JTextField fieldYear = test.getTextFieldYear();
		fieldYear.getText();
}
}
